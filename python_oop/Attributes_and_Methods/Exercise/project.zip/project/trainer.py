class Trainer:
    __counter = 0

    def __init__(self, name: str):
        self.name = name
        type(self).__counter += 1
        self.id = self.__counter

    def __repr__(self):
        return f"Trainer <{self.id}> {self.name}"

    @staticmethod
    def get_next_id():
        return Trainer.__counter + 1