class Equipment:
    __counter = 0

    def __init__(self, name: str):
        self.name = name
        type(self).__counter += 1
        self.id = self.__counter

    @staticmethod
    def get_next_id():
        return Equipment.__counter + 1

    def __repr__(self):
        return f"Equipment <{self.id}> {self.name}"

